<?php

$servername = "localhost";
$username = "root";
$password = "root";
$database = "exampleDatabase";

// Create connection
$connection = new mysqli($servername, $username, $password, $database);

// Check connection
if ($connection->connect_error) {
  die("Connection failed: " . $connection->connect_error);
}

echo "Connected successfully" . '<br>';

$createDatabaseSql = "CREATE DATABASE exampleDatabase";
if ($connection->query($createDatabaseSql) === TRUE) {
  echo "Database created successfully";
} else {
  echo "Error creating database: " . $connection->error;
}

$createPostsTableSql = "CREATE TABLE posts (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(30) NOT NULL,
    text VARCHAR(30) NOT NULL
)";
    
if ($connection->query($createPostsTableSql) === TRUE) {
    echo "Table posts created successfully";
} else {
    echo "Error creating table: " . $connection->error;
}

$connection->close();