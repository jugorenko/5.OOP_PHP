<?php

abstract class Fruit {

    private $name;
    private $color;

    public function __construct($name, $color)
    {
        $this->name = $name;
        $this->color = $color;
    }

    public function getName() 
    {
        return $this->name;
    }

    public function getColor()
    {
        return $this->color;
    }

    abstract public function getPrice();
} 

class Apple extends Fruit
{
    private const APPLE_PRICE = 5;
    private const APPLE_ADDITIONAL_PRICE_MULTIPLIER = 2;

    public function getPrice()
    {
        return self::APPLE_PRICE * self::APPLE_ADDITIONAL_PRICE_MULTIPLIER;
    }
}

class Banana extends Fruit 
{
    private const BANANA_PRICE = 5;
    private const BANANA_ADDITIONAL_PRICE_MULTIPLIER = 3;

    public function getPrice() 
    {
        return self::BANANA_PRICE * self::BANANA_ADDITIONAL_PRICE_MULTIPLIER;
    }
}

class Strawberry extends Fruit
{
    private const STRAWBERRY_PRICE = 5;

    public function getPrice()
    {
        return self::STRAWBERRY_PRICE;
    }
}

$apple = new Apple('Apple', 'Yellow');
$banana = new Banana('Banana', 'Yellow');
$strawberry = new Strawberry('Strawberry', 'Red');

$fruits = [$apple, $banana, $strawberry];

foreach ($fruits as $fruit) {
    echo 'This is an ' 
    . $fruit->getName() . ' it is colored ' 
    . $fruit->getColor() . ' and it has price ' 
    . $fruit->getPrice() . '<br>';
}
