<?php

class Fruit {

    private $name;
    private $color;

    public function setName($name)
    {
        $this->name = $name;
    }

    public function setColor($color)
    {
        $this->color = $color;
    }

    public function getName() 
    {
        return $this->name;
    }

    public function getColor()
    {
        return $this->color;
    }
} 



$apple = new Fruit();
$apple->setName('Apple');
$apple->setColor('Red');

echo 'Hello, this fruit is ' . $apple->getName() . ' it\'s color is ' . $apple->getColor() . '<br>';

$banana = new Fruit();
$banana->setName('Banana');
$banana->setColor('Yellow');

echo 'Hello, this fruit is ' . $banana->getName() . ' it\'s color is ' . $banana->getColor() . '<br>';