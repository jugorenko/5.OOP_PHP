<html>

<head>
    <style>
        .required {
            color: red;
        }
    </style>
</head>
<body>

<?php
    $name = '';
    $email = '';

    $nameError = '';
    $emailError = '';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        if (!$_POST['name']) {
            $nameError = 'Name must be provided';
        }

        if (!$_POST['email']) {
            $emailError = 'Email must be provided';
        }

        if ($_POST['name']) {
            $name = $_POST['name'];
        }

        if ($_POST['email']) {
            $email = $_POST['email'];
        }
    }
?>

<ul class="required">
    <?php echo $nameError !== '' ? '<li>' . $nameError . '</li>' : ''; ?>
    <?php echo $emailError !== '' ? '<li>' . $emailError . '</li>' : ''; ?>
</ul>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
    Name: <input class="<?php echo $nameError !== '' ? 'required' : '' ?> type="text" name="name" value="<?php echo $name ?>">
    E-mail: <input type="text" name="email" value="<?php echo $email ?>"><br>

    <input type="submit">
</form>

</body>
</html>