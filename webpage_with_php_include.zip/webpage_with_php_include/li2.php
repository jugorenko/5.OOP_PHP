<?php 

abstract class Saraksts {

    protected $title;
    protected $leadText;
    protected $contentText;

    public function __construct($title)
    {
        $this->title = $title;

    }

    abstract public function generateHtml();
}

class Punkts extends Saraksts 
{
    public function generateHtml()
    {
        return '<div class="recipe" style="color: green;">' 
        . '<h6>' . $this->title . '</h6>'
        .'</div>';
    }
}

$re1 = new Punkts('Coffee');
$re2 = new Punkts('Tea');
$re3 = new Punkts('Milk');

$saturs = [$re1, $re2, $re3];
?>

<nav class="nav">
    <ul>
        <?php foreach ($saturs as $saturaElements) { ?>
            <li class="<?php echo $saturaElements->generateHtml(); ?> 
            </li>
        <?php } ?>
    </ul>
 </nav>
