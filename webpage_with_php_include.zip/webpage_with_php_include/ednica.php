<?php
echo "<p>Paldies, ka apmeklējāt lapu!" . "<br>" ;
echo date("Y") . "</p>";
?>