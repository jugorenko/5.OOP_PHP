<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .menu {
            color: red;
        }

        .products {
            color: green;
        }

        .contacts {
            color: blue;
        }
    </style>
</head>
<body>

    <section class="content">
        <?php 
            include_once 'views/nav.php';
            include_once 'views/header.php';
        ?>

        <?php 

        $posts = [
            [
                'id' => 1,
                'title' => 'Post 1',
                'text' => 'Post 1 text',
                'is_visible' => false,
            ],
            [
                'id' => 2,
                'title' => 'Post 2',
                'text' => 'Post 2 text',
                'is_visible' => true,
            ],
            [
                'id' => 3,
                'title' => 'Post 3',
                'text' => 'Post 3 text',
                'is_visible' => true,
            ],
            [
                'id' => 4,
                'title' => 'Post 4',
                'text' => 'Post 4 text',
                'is_visible' => true,
            ],
            [
                'id' => 5,
                'title' => 'Post 5',
                'text' => 'Post 5 text',
                'is_visible' => true,
            ],
        ];
        ?>

        <?php foreach($posts as $post) { ?>
            <?php if ($post['is_visible']) { ?>
                <?php echo $post['title']; ?>
            <?php } ?>
        <?php } ?>
    </section>
</body>
</html>