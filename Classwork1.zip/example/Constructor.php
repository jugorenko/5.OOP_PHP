<?php

class Fruit {

    private $name;
    private $color;

    public function __construct($name, $color)
    {
        $this->name = $name;
        $this->color = $color;
    }

    public function getName() 
    {
        return $this->name;
    }

    public function getColor()
    {
        return $this->color;
    }
} 


$apple = new Fruit('Apple', 'Red');

echo 'Hi, this fruit is ' . $apple->getName() . ' it\'s color is ' . $apple->getName() . '<br>';

$banana = new Fruit('Banana', 'Yellow');

echo 'Hi, this fruit is ' . $banana->getName() . ' it\'s color is ' . $banana->getColor() . '<br>';