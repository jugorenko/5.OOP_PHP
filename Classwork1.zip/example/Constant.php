<?php

class Fruit {

    public const PRODUCT_TYPE = 'Fruitsz';
    private $type;
    private $name;
    private $color;

    public function __construct($name, $color)
    {
        $this->name = $name;
        $this->color = $color;
        $this->type = self::PRODUCT_TYPE;
    }

    public function getName() 
    {
        return $this->name;
    }

    public function getColor()
    {
        return $this->color;
    }

    public function getType()
    {
        return $this->type;
    }
}

class Vegetable {

    public const PRODUCT_TYPE = 'Vegetable';
    private $type;
    private $name;
    private $color;

    public function __construct($name, $color)
    {
        $this->name = $name;
        $this->color = $color;
        $this->type = self::PRODUCT_TYPE;
    }

    public function getName() 
    {
        return $this->name;
    }

    public function getColor()
    {
        return $this->color;
    }

    public function getType()
    {
        return $this->type;
    }
}


$apple = new Fruit('Apple', 'Red');
$banana = new Fruit('Banana', 'Yellow');
$potato = new Vegetable('Potato', 'Brown');
$tomato = new Vegetable('Tomato', 'Red');
echo 'Hi, this ' . $apple->getType() .  ' is ' . $apple->getName() . ' it\'s color is ' . $apple->getColor() . '<br>';
echo 'Hi, this ' . $apple->getType() .  ' is ' . $banana->getName() . ' it\'s color is ' . $banana->getColor() . '<br>';

$products = [$apple, $banana, $potato, $tomato];

$vegetables = 0;
$fruits = 0;

foreach ($products as $product) 
{
    if ($product->getType() === Fruit::PRODUCT_TYPE)
    {
        $fruits++;
    }

    if ($product->getType() === Vegetable::PRODUCT_TYPE)
    {
        $vegetables++;
    }
}

echo 'Fruits: ' . $fruits . '<br>';
echo 'Vegetables: ' . $vegetables . '<br>';