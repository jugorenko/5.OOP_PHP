<?php

interface HasComments 
{
    public function comments();
}

class Post implements HasComments 
{
    use InteractsWithComments;
}

class Article implements HasComments
{
    use InteractsWithComments;
}

class Recipe implements HasComments 
{
    use InteractsWithComments;
}

trait InteractsWithComments
{
    public function comments()
    {
        return [];
    }
}

echo (1);

