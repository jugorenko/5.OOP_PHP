<!DOCTYPE html>
<html>
<head>
<title>TOM-YUM ZUPAS</title>
<link rel="stylesheet" href="./tomyum.css">
<body>

    <h1>Zupas</h1>
      
    <p>Lūdzu, izvēlēties zupiņu no saraksta:</p>

    <form action="/action_page.php">
      <label for="soup">Zupas izvēle:</label>
      <select id="soup" name="soup">
        <option value="cheese">Siera</option>
        <option value="beans">Zirņu</option>
        <option value="meet">Gaļas</option>
        <option value="ousters">Austeru</option>
      </select>
      <input type="submit">
    </form>
    <h3>Ēdnīca</h3>
       <?php include 'li2.php';?>
    <h4>Āra kafejnīca</h4>
    <div class="myDiv">
        <h5>Auto</h5>
        <ol>
            <li>Coffee</li>
            <li>Tea</li>
            <li>Milk</li>
          </ol>
        <h6>Bistro</h6>
        <img alt="bistro" width="300" height="200" src="pic.jpg" >
    </div>
    <p>Labu apetīti!</p>
    <a target="_blank" href="https://www.seamless.com/menu/wok-wok-11-mott-st-new-york/467748">wok-to-wok 
    </a>
    </br>
    <a target="_blank" href="https://receptes.tvnet.lv/receptes/zupas">zupiņas 
    </a>
    </br>
    <a target="_blank" href="https://receptes.tvnet.lv/receptes/zupas">grauzdiņi 
    </a>
  
 
    <footer>      
      <h3>  <?php include 'ednica.php';?> </h3>
    </footer>
    
</body>


</html>
