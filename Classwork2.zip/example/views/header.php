<?php $myPageHeader = 'This is my page header'; ?>
<h1><?php echo($myPageHeader); ?></h1>