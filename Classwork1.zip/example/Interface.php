<?php

interface HasImageUrl {

    public function hasStoredImage(): bool;

    public function imageUrl(): string;
}

interface HasComments {

    public function comments(): array;
}

class Post implements HasImageUrl, HasComments
{
    public function hasStoredImage(): bool
    {
        return false;
    }

    public function imageUrl(): string
    {
        return 'google.com';
    }

    public function comments(): array
    {
        return [
            'Nice',
            'Good',
            'Bad',
        ];
    }
}

class Article implements HasImageUrl, HasComments
{
    public function hasStoredImage(): bool
    {
        return true;
    }

    public function imageUrl(): string
    {
        return '/images/artcile.png';
    }

    public function comments(): array
    {
        return [
            'Wow',
            'Sad',
            'Good looking',
        ];
    }
}

$post = new Post();
$article = new Article();

$content = [$post, $article];

foreach ($content as $block) 
{
    if ($block->hasStoredImage()) {
        echo $block->imageUrl() . '<br>';
    } else {
        echo 'No images' . '<br>';
    }
}
