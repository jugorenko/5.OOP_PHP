<?php 
    $navigation = [
        [
            'name' => 'Menu',
            'class' => 'menu'
        ],
        [
            'name' => 'Products',
            'class' => 'products'
        ],
        [
            'name' => 'Contacts',
            'class' => 'contacts'
        ],
    ];
?>

<nav class="nav">
    <ul>
        <?php foreach($navigation as $navigationElement) { ?>
            <li class="<?php echo $navigationElement['class']?>">
                <?php echo $navigationElement['name']; ?> 
            </li>
        <?php } ?>
    </ul>
</nav>