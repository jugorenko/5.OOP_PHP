<?php 

abstract class ContentBlock {

    protected $title;
    protected $leadText;
    protected $contentText;

    public function __construct($title, $leadText, $contentText)
    {
        $this->title = $title;
        $this->leadText = $leadText;
        $this->contentText = $contentText;
    }

    abstract public function generateHtml();
}

class Article extends ContentBlock
{
    public function generateHtml()
    {
        return '<div class="article" style="color: red;">' 
        . '<h1>' . $this->title . '</h1>'
        . '<h2>' . $this->leadText . '</h2>'
        . '<p>' . $this->contentText . '</p>'
        .'</div><br>';
    }
}

class Recipe extends ContentBlock 
{
    public function generateHtml()
    {
        return '<div class="recipe" style="color: green;">' 
        . '<h1>' . $this->title . '</h1>'
        . '<h2>' . $this->leadText . '</h2>'
        .'</div><br>';
    }
}

class BlogPost extends ContentBlock 
{
    public function generateHtml()
    {
        return 'No blogs available now';
    }
}

$article1 = new Article('Article 1 title', 'Article 1 lead text', 'Article 1 content text');
$article2 = new Article('Article 2 title', 'Article 2 lead text', 'Article 2 content text');
$article3 = new Article('Article 3 title', 'Article 3 lead text', 'Article 3 content text');
$article4 = new Article('Article 4 title', 'Article 4 lead text', 'Article 4 content text');
$recipe1 = new Recipe('Recipe 1 title', 'Recipe 1 lead text', '');
$recipe2 = new Recipe('Recipe 2 title', 'Recipe 2 lead text', '');
$blogPost1 = new BlogPost('Blog post 1 title', 'Blog post 1 lead text', '');
$blogPost2 = new BlogPost('Blog post 2 title', 'Blog post 2 lead text', '');

$contentBlocks = [$blogPost1, $article1, $recipe1, $article2, $article3, $recipe2, $article4, $blogPost2];

foreach ($contentBlocks as $contentBlock)
{
    echo $contentBlock->generateHtml();
}