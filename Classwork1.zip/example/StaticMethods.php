<?php 

class Greeting
{
    private $greetingName;
    
    private static function sayHello(string $name): string
    {
        return 'Hello, ' . $name . '<br>';
    }

    public static function hello(string $name): string 
    {
        return self::sayHello($name);
    }
}

echo Greeting::hello('Nikita');