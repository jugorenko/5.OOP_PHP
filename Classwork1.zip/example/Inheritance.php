<?php

class Product {

    protected $name;
    protected $color;

    public function __construct($name, $color)
    {
        $this->name = $name;
        $this->color = $color;
    }

    public function getName() 
    {
        return $this->name;
    }

    public function getColor()
    {
        return $this->color;
    }
}

class Car extends Product
{
    private $wheelCount;

    public function setWheelCount($wheelCount)
    {
        $this->wheelCount = $wheelCount;
    }

    public function getWheelCount()
    {
        return $this->wheelCount;
    }
}

class Banana extends Product 
{
    public function getName() 
    {
        return 'This is a fruit named ' . $this->name;
    }
}

$car = new Car('BMW', 'Red');
$car->setWheelCount(4);
echo 'This is an ' . $car->getName() . ' and it has : ' . $car->getWheelCount() . ' wheels' . '<br>';

$banana = new Banana('Banana', 'Yellow');
echo $banana->getName() . ' and it\'s color is ' . $banana->getColor() . '<br>';


